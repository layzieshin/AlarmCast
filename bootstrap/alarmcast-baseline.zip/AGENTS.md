# AGENTS.md

Zentrale Anweisung fuer alle Coding Agents in diesem Repository. Detaillierte Situationsregeln stehen unter `.cursor/rules/*.mdc`. Fachliche und technische Tiefe steht unter `docs/`.

## Projekt

**Alarmcast** ist eine Windows-Anwendung fuer Praxis-/Labor-Umgebungen. Ein Host-PC (z. B. an einem Analysengeraet) erfasst seinen Systemton per WASAPI-Loopback und streamt ihn an Clients (Arzt-PCs). Bei einem definierten Signalmuster (Default: 2 Toene in 3 s) zeigen alle Clients zusaetzlich ein gelbes Warndreieck oben rechts auf jedem Monitor. Pro Client sind Lautstaerke und Mute regelbar (Patientenkontakt).

Vollstaendige Fachbeschreibung: [docs/project-brief.md](docs/project-brief.md).
Architektur und Datenfluss: [docs/architecture.md](docs/architecture.md).
Architekturentscheidungen: [docs/decisions/](docs/decisions/).

## Stack

- Python **3.12**
- GUI: **PySide6** (Qt) — Tray, Fenster, Multi-Monitor-Overlay.
- Audio: **soundcard** (WASAPI-Loopback am Host), **sounddevice** (Output am Client).
- Numerik: **numpy** (Pin `==1.26.4` wegen `frombuffer`-Kompatibilitaet aelterer Audio-Libs).
- Netzwerk: TCP mit eigenem Frame-Layout (`core/protocol.py`).
- Discovery: **zeroconf** (mDNS, Service `_alarmcast._tcp.local.`).
- Build: **PyInstaller** (`--onefile --noconsole`).
- Dev-Tools: `ruff` (format + lint), `mypy`, `pytest`.

Begruendung der Stack-Wahl: [docs/decisions/0001-initial-architecture.md](docs/decisions/0001-initial-architecture.md).

## Repo-Layout

Einzelne Binary mit Modus-Schalter:

```text
alarmcast --host       # auf dem PC am Analysengeraet
alarmcast --client     # auf jedem Arzt-PC
```

```text
src/alarmcast/
  __main__.py
  core/      # gemeinsam (protocol, audio_format, config, discovery, security, alarm_logic, logging_setup)
  host/      # nur fuer --host (capture, server, detector, app)
  client/    # nur fuer --client (net, output, overlay, app)
```

Importgrenzen siehe `.cursor/rules/project-architecture.mdc`.

## Schluesselbefehle

Phase 2 (aktuell): Projektgeruest vorhanden.

Build/Run/Test-Befehle:

```text
Run:            python -m alarmcast --host | --client
Tests:          pytest
Lint/Format:    ruff check .  |  ruff format --check .
Typen:          mypy src
EXE-Build:      pyinstaller alarmcast.spec
EXE-Debug:      pyinstaller alarmcast-debug.spec
```

## Done-Definition fuer eine Aufgabe

Eine Aufgabe gilt erst als fertig, wenn **alle** Punkte zutreffen:

1. Code aendert genau das, was die Aufgabe verlangt — nicht mehr, nicht weniger.
2. Geaenderte Module sind dokumentiert (Docstrings, falls API).
3. Tests sind angepasst/ergaenzt **oder** eine manuelle Pruefliste ist im Abschlussbericht angegeben.
4. `ruff check`, `mypy`, `pytest` laufen lokal gruen (sobald Phase 2 lief).
5. Abschlussbericht im Chat: geaenderte Dateien, ausgefuehrte Pruefungen, Ergebnis, offene Punkte.

## Verbote

Diese Dinge darf der Agent **niemals eigenstaendig** entscheiden oder tun:

- Stack-Wechsel oder neue Top-Level-Dependencies hinzufuegen (immer nachfragen).
- Architekturentscheidungen auf Verdacht treffen — neue ADR oeffnen oder Frage stellen.
- Bestehende Funktionalitaet stillschweigend entfernen.
- Geheimnisse (PSK, Tokens, IPs) ins Repo committen.
- TCP-Subnet-Scans implementieren (AV/EDR-Risiko, verworfen in ADR 0001).
- Konfiguration ausserhalb von `%APPDATA%\AlarmCast\` lesen oder schreiben.
- Mit `print()` loggen — `logging` via `core/logging_setup.py` verwenden.

## Bei Unklarheit

- Erst fragen, dann editieren. Bei mehreren plausiblen Wegen: 2 Optionen mit Trade-offs vorschlagen.
- Aenderungen klein und nachvollziehbar halten; ein Thema pro Edit-Runde.

## Wo finde ich was

- Architektur-/Importregeln: `.cursor/rules/project-architecture.mdc`
- Aenderungen an bestehenden Dateien: `.cursor/rules/safe-existing-file-edits.mdc`
- Tests/Build/Manuelle Pruefung: `.cursor/rules/verification.mdc`
- Coding-Stil/Logging: `.cursor/rules/code-style.mdc`
- Aktueller Bauplan: `.cursor/plans/initial-project-setup.md`
