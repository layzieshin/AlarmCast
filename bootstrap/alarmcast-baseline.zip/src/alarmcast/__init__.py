"""Alarmcast package."""
