# Alarmcast

Windows-Werkzeug fuer Praxis-/Labor-Umgebungen, das Warntoene eines Geraete-PCs (z. B. an einem Analysengeraet) an Arzt-PCs im LAN streamt und bei einem definierten Signalmuster zusaetzlich ein optisches Warndreieck auf jedem Monitor zeigt.

Eine Binary, zwei Modi:

```text
alarmcast --host       # auf dem PC am Analysengeraet
alarmcast --client     # auf jedem Arzt-PC
```

## Dokumentation

- [Projekt-Brief](docs/project-brief.md) — fachliche Kurzbeschreibung
- [Architektur](docs/architecture.md) — Datenfluss, Module, Protokoll, Konfiguration
- [Architekturentscheidungen](docs/decisions/) — ADRs
- [Anweisungen fuer Coding Agents](AGENTS.md)

## Quickstart

```powershell
# Python 3.12 erforderlich
pip install -e ".[dev]"
python -m alarmcast --host
python -m alarmcast --client
```

EXE starten:

```powershell
# Empfohlen: Verknuepfung mit Argument
dist\alarmcast.exe --host
dist\alarmcast.exe --client

# Oder Doppelklick: Modus-Dialog erscheint (Wahl wird in
# %APPDATA%\AlarmCast\mode.txt gespeichert)
dist\alarmcast.exe
```

EXE-Build:

```powershell
pyinstaller alarmcast.spec
# Debug-Build (Konsolenfenster bei Fehlern):
pyinstaller alarmcast-debug.spec
```

Verknuepfungen anlegen (Windows):

- Ziel Host: `"C:\Pfad\alarmcast.exe" --host`
- Ziel Client: `"C:\Pfad\alarmcast.exe" --client`

Manueller End-to-End-Test: [tests/manual_smoke.md](tests/manual_smoke.md)
